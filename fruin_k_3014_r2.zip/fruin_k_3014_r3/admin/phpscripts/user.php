<?php
	function createUser($fname, $username, $password, $email, $userlvl) {
		include('connect.php');
		$userString = "INSERT INTO tbl_user VALUES(NULL, '{$fname}', '{$username}', '{$password}', '{$email}', NULL, '{$userlvl}', 'no')";
		//echo $userString;
	$userQuery = mysqli_query($link, $userString);
		if($userQuery) {
			sendmessage($email, $username, $password);
			//Email message, the email needs a username and password.
			//The mail.php file is the code to generate this.
			redirect_to("admin_index.php");
		}else{
			$message = "There was a problem setting up this user. Contact your system administrator for assistance.";
			return $message;
		}
	mysqli_close($link);
}

?>
